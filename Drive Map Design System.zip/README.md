# Drive Map Design System

A design system for **drivemap.py** — a Python CLI tool that recursively maps a Google Drive "Shared with me" folder and outputs a searchable, filterable HTML report plus a Markdown summary. The product is a single static HTML artifact — the report itself — so this design system codifies the visual vocabulary needed to extend it into new surfaces without drifting.

> ⚠️ The only product surface today is the generated `drive_map.html` report. Everything else is **extrapolated from the report's DNA** — extending a single artifact into a broader system.

---

## Direction

**Modern, spacious, light-theme.** Originally the report was dense and slightly retro-admin — 13px body, tight rows, dark sidebar. This system takes that functional core and re-paints it for readability:

- **Light sidebar** (was dark slate-800). White panel, indigo-tinted active state.
- **Generous type scale.** 15px body, 28px page title, 36px stat numbers. Geist for everything.
- **Loose spacing.** 14–40px padding; table cells at 14×20px.
- **High-contrast text.** Body at slate-900; muted text at slate-600 for AAA readability.
- **Kept the polychromatic badge palette** — color → file-type is the product's strongest affordance. Fg colors were deepened for contrast within each pastel pair.

---

## Sources

| Source | Path |
|---|---|
| GitHub repo | [jonathanw00/Google-Drive-Map](https://github.com/jonathanw00/Google-Drive-Map) |
| Imported script | `reference/drivemap.py` |
| Imported README | `reference/original_README.md` |

---

## Content Fundamentals

**Voice: helpful peer, not a brand.** In-UI copy is third-person and terse — labels and counts, never sentences.

**Casing:**
- Section eyebrows are `UPPERCASE` with 0.06em tracking ("FOLDER TREE", "DRIVE MAP REPORT")
- Column headers are `UPPERCASE` with 0.05em tracking
- Badge labels are `Title Case` ("PDF", "Word Doc", "PowerPoint")
- State flags are `ALL CAPS` short codes ("DUPLICATE", "EMPTY")

**Emoji:** used functionally as file-type glyphs inline before names (📂 📁 📕 📗 📘 📙 🎵 🎬). Never decorative.

---

## Visual Foundations

### Color

- **Neutral** — full slate scale (#f8fafc → #0f172a). App bg = `#fafafa`, panels = white, sidebar = white.
- **Accent** — `indigo-600 (#4f46e5)` for links, active scroll-spy, FAB, focus.
- **File-type palette** is polychromatic pastel bg + AAA-dark fg — red pdf, blue word, green excel, orange slides, indigo folder, purple audio, amber video, slate other.
- **Semantic states** — amber `#fffbeb` for duplicate rows, violet `#ede9fe/#4c1d95` for empty folders, blue `#eff6ff/#1e3a8a` for inline-expanded Excel.

### Type

**Geist** (sans) + **Geist Mono** loaded from Google Fonts. Body `15px/1.55`, eyebrow `11px/600/caps/0.04em`, stat numbers `36px/600/-0.02em`, page title `28px/600/-0.025em`.

### Spacing

4 / 8 / 12 / 16 / 20 / 24 / 32 / 40 / 48 / 64. Stat cards pad 16×20, table cells 14×20, sidebar items 7×10, main content padding 40px horizontal.

### Radii

sm 6 · md 10 · lg 12 · xl 16 · pill 9999. Cards and inputs use 10–14; pills/chips 9999.

### Shadows

- `shadow-card` — `0 1px 3px rgba(15,23,42,0.04), 0 1px 2px rgba(15,23,42,0.03)` (table)
- `shadow-md` — `0 4px 12px rgba(15,23,42,0.06)` (popovers)
- `shadow-fab` — `0 8px 24px rgba(99,102,241,0.32)` (colored indigo halo on the FAB)

### Motion

- Hover/state transitions: `0.15s cubic-bezier(0.2, 0, 0, 1)`
- `rowFlash` keyframe for scroll-spy navigation (1.4s, indigo-100 bg, fades out)

---

## Index / Manifest

```
/
├── README.md                  — this file
├── SKILL.md                   — skill manifest for Claude Code
├── colors_and_type.css        — design tokens
├── reference/                 — original source (drivemap.py + README)
├── assets/favicon.svg
├── preview/                   — design system cards
└── ui_kits/
    └── drive_map_report/
        ├── index.html         — full interactive recreation
        ├── Sidebar.jsx
        ├── SummaryBar.jsx
        ├── SearchBar.jsx
        ├── FileTable.jsx
        ├── Badges.jsx
        └── sampleData.js
```

---

## Using this system

**For mocks:** link `colors_and_type.css` and copy components from `ui_kits/drive_map_report/`.

**For production code:** source of truth is still `reference/drivemap.py`. This system codifies what's there so new screens can stay consistent without reverse-engineering the embedded CSS string.
