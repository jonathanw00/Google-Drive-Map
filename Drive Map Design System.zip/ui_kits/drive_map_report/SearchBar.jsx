/* global React */
function SearchBar({ value, onChange, resultLabel }) {
  return (
    <>
      <div className="search-wrap">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="11" cy="11" r="7"></circle>
          <path d="m21 21-4.3-4.3"></path>
        </svg>
        <input
          id="search"
          type="search"
          placeholder="Search files, folders, or descriptions…"
          autoComplete="off"
          value={value}
          onChange={e => onChange(e.target.value)}
        />
      </div>
      <span id="search-count">{resultLabel}</span>
    </>
  );
}

function TypeFilter({ active, onChange }) {
  const types = [
    { key: "all",    label: "All" },
    { key: "pdf",    label: "PDF" },
    { key: "word",   label: "Word" },
    { key: "excel",  label: "Excel" },
    { key: "audio",  label: "Audio" },
    { key: "video",  label: "Video" },
    { key: "folder", label: "Folder" },
  ];
  return (
    <div id="type-filter">
      {types.map(t => (
        <button
          key={t.key}
          className={`type-btn ${active === t.key ? "active" : ""}`}
          data-type={t.key}
          onClick={() => onChange(t.key)}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}

window.SearchBar = SearchBar;
window.TypeFilter = TypeFilter;
