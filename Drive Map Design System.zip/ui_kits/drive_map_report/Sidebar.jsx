/* global React */
const { useState } = React;

function Sidebar({ title, tree, activeAnchor, onNavigate }) {
  const [collapsed, setCollapsed] = useState(new Set());

  const toggle = (id) => {
    const next = new Set(collapsed);
    next.has(id) ? next.delete(id) : next.add(id);
    setCollapsed(next);
  };

  const byId = Object.fromEntries(tree.map(n => [n.id, n]));

  const renderNode = (node) => {
    const hasChildren = node.children && node.children.length > 0;
    const isCollapsed = collapsed.has(node.id);
    const isActive = activeAnchor === node.id;

    const pad = node.root ? 8 : 8 + (node.depth * 14);

    return (
      <li key={node.id} className="tree-node">
        <div
          className={`tree-item ${isActive ? "item-active" : ""}`}
          style={{ paddingLeft: pad }}
        >
          {hasChildren ? (
            <span className="tree-arrow" onClick={() => toggle(node.id)}>
              {isCollapsed ? "▸" : "▾"}
            </span>
          ) : (
            <span className="tree-spacer" />
          )}
          <a
            href={`#${node.id}`}
            className={`tree-link ${node.root ? "tree-root-link" : ""}`}
            title={node.name}
            onClick={(e) => { e.preventDefault(); onNavigate(node.id); }}
          >
            <span className="icon">{node.root ? "📂" : "📁"}</span>
            {node.name}
          </a>
        </div>
        {hasChildren && !isCollapsed && (
          <ul className="tree-children">
            {node.children.map(cid => byId[cid] && renderNode(byId[cid]))}
          </ul>
        )}
      </li>
    );
  };

  const root = tree.find(n => n.root);

  return (
    <div id="sidebar">
      <div id="sidebar-header">
        <div className="eyebrow">Folder Tree</div>
        <div className="folder-name">{title}</div>
        <div id="sidebar-controls">
          <button className="sidebar-btn" onClick={() => setCollapsed(new Set(tree.filter(n => n.children && n.children.length).map(n => n.id)))}>
            Collapse all
          </button>
          <button className="sidebar-btn" onClick={() => setCollapsed(new Set())}>
            Expand all
          </button>
        </div>
      </div>
      <div id="sidebar-tree">
        <ul className="tree-root">{root && renderNode(root)}</ul>
      </div>
    </div>
  );
}

window.Sidebar = Sidebar;
