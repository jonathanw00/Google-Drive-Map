/* global React, TypeBadge, DupBadge, EmptyBadge */
function fileIcon(mime) {
  switch (mime) {
    case "pdf":    return "📕";
    case "word":   return "📘";
    case "excel":  return "📗";
    case "slides": return "📙";
    case "audio":  return "🎵";
    case "video":  return "🎬";
    default:       return "📄";
  }
}

function FileTable({ rows, flashedRow }) {
  return (
    <table>
      <thead>
        <tr>
          <th>File Name</th>
          <th>Type</th>
          <th>Modified</th>
          <th>Description</th>
        </tr>
      </thead>
      <tbody id="file-table">
        {rows.map(r => <FileRows key={r.id} row={r} flashed={flashedRow === (r.anchor || r.id)} />)}
      </tbody>
    </table>
  );
}

function FileRows({ row, flashed }) {
  const isFolder = row.mime === "folder";
  const rowId = row.anchor || `row-${row.id}`;
  const indent = row.depth * 22 + 20;
  const icon = isFolder ? "📁" : fileIcon(row.mime);

  const cls = [
    "file-row", "filterable",
    row.duplicate ? "duplicate" : "",
    flashed ? "row-flash" : ""
  ].join(" ");

  return (
    <>
      <tr id={rowId} className={cls}>
        <td className="name-cell" style={{ paddingLeft: indent }}>
          <a href={row.link || "#"} target="_blank" rel="noreferrer" className="file-link">
            <span className="icon">{icon}</span>
            <span>{row.name}</span>
          </a>
          {row.duplicate && <DupBadge />}
          {row.emptyFolder && <EmptyBadge />}
          {row.duplicate && row.path && (
            <div className="breadcrumb">{row.path.join(" / ")}</div>
          )}
        </td>
        <td><TypeBadge mime={row.mime} /></td>
        <td className="date-cell">{row.modified}</td>
        <td className="desc-cell">{row.desc}</td>
      </tr>
      {row.xlsx && row.xlsx.length > 0 && (
        <>
          <tr className="xlsx-header">
            <td style={{ paddingLeft: indent + 24 }}>Resource Type</td>
            <td>Title</td>
            <td colSpan="2">Add'l Info</td>
          </tr>
          {row.xlsx.map((xr, i) => (
            <tr key={i} className="xlsx-resource-row">
              <td style={{ paddingLeft: indent + 24 }}>{xr.type}</td>
              <td>
                {xr.link
                  ? <a href={xr.link} target="_blank" rel="noreferrer" className="xlsx-link">{xr.title}</a>
                  : xr.title}
              </td>
              <td colSpan="2">{xr.info}</td>
            </tr>
          ))}
        </>
      )}
    </>
  );
}

window.FileTable = FileTable;
