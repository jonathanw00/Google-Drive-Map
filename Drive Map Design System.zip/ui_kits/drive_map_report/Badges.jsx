/* global React */
const { useState } = React;

const TYPE_META = {
  pdf:    { label: "PDF",            cls: "badge-pdf"    },
  word:   { label: "Word Doc",       cls: "badge-doc"    },
  excel:  { label: "Excel",          cls: "badge-sheet"  },
  slides: { label: "PowerPoint",     cls: "badge-slides" },
  folder: { label: "Folder",         cls: "badge-folder" },
  audio:  { label: "MP3 Audio",      cls: "badge-audio"  },
  video:  { label: "MP4 Video",      cls: "badge-video"  },
  other:  { label: "Other",          cls: "badge-other"  },
};

function TypeBadge({ mime }) {
  const m = TYPE_META[mime] || TYPE_META.other;
  return <span className={`badge ${m.cls}`}>{m.label}</span>;
}

function DupBadge() {
  return <span className="dup-badge">DUPLICATE</span>;
}
function EmptyBadge() {
  return <span className="empty-badge">EMPTY</span>;
}

window.TYPE_META = TYPE_META;
window.TypeBadge = TypeBadge;
window.DupBadge = DupBadge;
window.EmptyBadge = EmptyBadge;
