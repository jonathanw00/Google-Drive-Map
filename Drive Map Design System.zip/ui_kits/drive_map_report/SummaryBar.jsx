/* global React */
function SummaryBar({ title, counts, emptyActive, onToggleEmpty }) {
  return (
    <div id="summary">
      <div id="summary-title">
        <div className="eyebrow">Drive Map Report</div>
      </div>
      <h1>{title}</h1>
      <div id="summary-stats">
        <div className="stat-card">
          <div className="stat-num">{counts.files}</div>
          <div className="stat-label">Files</div>
        </div>
        <div className="stat-card">
          <div className="stat-num">{counts.folders}</div>
          <div className="stat-label">Folders</div>
        </div>
        <div className="stat-card stat-dup">
          <div className="stat-num">{counts.duplicates}</div>
          <div className="stat-label">Duplicates</div>
        </div>
        <div
          className={`stat-card stat-empty clickable ${emptyActive ? "active" : ""}`}
          onClick={onToggleEmpty}
          title="Filter to empty folders"
        >
          <div className="stat-num">{counts.empty}</div>
          <div className="stat-label">Empty Folders</div>
        </div>
      </div>
    </div>
  );
}

window.SummaryBar = SummaryBar;
