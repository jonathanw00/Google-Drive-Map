// Sample fixture approximating a CFJ-style shared folder
window.SAMPLE_DATA = {
  rootName: "NEW CFJ RESOURCE FOLDER Rev 2024",
  stats: { files: 24, folders: 8, duplicates: 2, empty: 1 },
  tree: [
    { id: "root", depth: 0, name: "NEW CFJ RESOURCE FOLDER Rev 2024", root: true, children: ["w1","w2","admin","archive"] },
    { id: "w1", depth: 1, name: "Week 1 — Onboarding", children: ["w1-tpl","w1-res"] },
    { id: "w1-tpl", depth: 2, name: "Templates", children: [] },
    { id: "w1-res", depth: 2, name: "Resources", children: [] },
    { id: "w2", depth: 1, name: "Week 2 — Deep Dive", children: [] },
    { id: "admin", depth: 1, name: "Admin & Legal", children: [] },
    { id: "archive", depth: 1, name: "Archive (2023)", children: ["archive-empty"] },
    { id: "archive-empty", depth: 2, name: "Notes (to sort)", children: [], empty: true },
  ],
  rows: [
    // top-level files
    { id: "f-overview", parent: "root", depth: 1, name: "Program Overview.pdf", mime: "pdf", desc: "PDF document — Program Overview", modified: "Sep 3, 2024" },
    { id: "f-welcome", parent: "root", depth: 1, name: "Welcome Letter.docx", mime: "word", desc: "Word document — Welcome Letter", modified: "Sep 3, 2024" },
    { id: "f-links", parent: "root", depth: 1, name: "1 LINKS — Resource Index.xlsx", mime: "excel", desc: "Excel spreadsheet — resource index", modified: "Nov 2, 2024",
      xlsx: [
        { type: "Template", title: "Kickoff Deck Template", link: "https://docs.google.com/presentation/d/1abc/edit", info: "Use for Week 1 sessions" },
        { type: "Worksheet", title: "Audit Checklist", link: "https://docs.google.com/spreadsheets/d/2def/edit", info: "Fill before demo day" },
        { type: "Reading", title: "Intro to Restorative Practice", link: "https://example.org/reading", info: "~20 min read" },
        { type: "Video", title: "Trainer Q&A (recorded)", link: "https://drive.google.com/file/d/3ghi/view", info: "90 min, closed captions" },
      ]
    },
    // w1 folder
    { id: "fld-w1", parent: "root", depth: 1, name: "Week 1 — Onboarding", mime: "folder", desc: "Google Drive folder", modified: "Aug 14, 2024", anchor: "w1" },
      { id: "f-kickoff", parent: "fld-w1", depth: 2, name: "Kickoff Agenda.pdf", mime: "pdf", desc: "PDF document — Kickoff Agenda", modified: "Aug 14, 2024" },
      { id: "f-roster", parent: "fld-w1", depth: 2, name: "Roster.xlsx", mime: "excel", desc: "Excel spreadsheet — Roster", modified: "Aug 12, 2024" },
      // Templates
      { id: "fld-tpl", parent: "fld-w1", depth: 2, name: "Templates", mime: "folder", desc: "Google Drive folder", modified: "Aug 14, 2024", anchor: "w1-tpl" },
        { id: "f-tpl-agenda", parent: "fld-tpl", depth: 3, name: "Kickoff Agenda.pdf", mime: "pdf", desc: "PDF document — Kickoff Agenda", modified: "Jul 22, 2024", duplicate: true, path: ["NEW CFJ RESOURCE FOLDER","Week 1 — Onboarding","Templates"] },
        { id: "f-tpl-email", parent: "fld-tpl", depth: 3, name: "Welcome Email Template.docx", mime: "word", desc: "Word document — Welcome Email", modified: "Jul 22, 2024" },
      // Resources
      { id: "fld-res", parent: "fld-w1", depth: 2, name: "Resources", mime: "folder", desc: "Google Drive folder", modified: "Aug 20, 2024", anchor: "w1-res" },
        { id: "f-res-handbook", parent: "fld-res", depth: 3, name: "Facilitator Handbook.pdf", mime: "pdf", desc: "PDF document — Facilitator Handbook", modified: "Aug 20, 2024" },
        { id: "f-res-intro", parent: "fld-res", depth: 3, name: "Intro Recording.mp3", mime: "audio", desc: "MP3 audio — Intro Recording", modified: "Aug 20, 2024" },
        { id: "f-res-slides", parent: "fld-res", depth: 3, name: "Opening Slides.pptx", mime: "slides", desc: "PowerPoint — Opening Slides", modified: "Aug 20, 2024" },
    // w2 folder
    { id: "fld-w2", parent: "root", depth: 1, name: "Week 2 — Deep Dive", mime: "folder", desc: "Google Drive folder", modified: "Sep 4, 2024", anchor: "w2" },
      { id: "f-w2-plan", parent: "fld-w2", depth: 2, name: "Session Plan.docx", mime: "word", desc: "Word document — Session Plan", modified: "Sep 4, 2024" },
      { id: "f-w2-vid", parent: "fld-w2", depth: 2, name: "Case Study.mp4", mime: "video", desc: "MP4 video — Case Study", modified: "Sep 4, 2024" },
      { id: "f-w2-readings", parent: "fld-w2", depth: 2, name: "Suggested Readings.pdf", mime: "pdf", desc: "PDF document — Suggested Readings", modified: "Sep 4, 2024" },
    // admin
    { id: "fld-admin", parent: "root", depth: 1, name: "Admin & Legal", mime: "folder", desc: "Google Drive folder", modified: "Oct 1, 2024", anchor: "admin" },
      { id: "f-nda", parent: "fld-admin", depth: 2, name: "Facilitator NDA.pdf", mime: "pdf", desc: "PDF document — NDA", modified: "Oct 1, 2024" },
      { id: "f-budget", parent: "fld-admin", depth: 2, name: "Budget.xlsx", mime: "excel", desc: "Excel spreadsheet — Budget", modified: "Oct 1, 2024" },
      { id: "f-contract", parent: "fld-admin", depth: 2, name: "Contract Template.docx", mime: "word", desc: "Word document — Contract Template", modified: "Oct 1, 2024" },
    // archive
    { id: "fld-archive", parent: "root", depth: 1, name: "Archive (2023)", mime: "folder", desc: "Google Drive folder", modified: "Dec 15, 2023", anchor: "archive" },
      { id: "f-archive-handbook", parent: "fld-archive", depth: 2, name: "Facilitator Handbook.pdf", mime: "pdf", desc: "PDF document — Facilitator Handbook (archived)", modified: "Dec 15, 2023", duplicate: true, path: ["NEW CFJ RESOURCE FOLDER","Archive (2023)"] },
      { id: "f-archive-notes", parent: "fld-archive", depth: 2, name: "Notes (to sort)", mime: "folder", desc: "Google Drive folder", modified: "Dec 15, 2023", anchor: "archive-empty", emptyFolder: true },
  ],
};
